%initialize parameters

p.text_size = 35;
p.text_font = 'Times New Roman';
%p.number_font_size=30;
p.video_latency=0.026; %0.033


p.nTrials = 200;
p.useim = [13:24 49:60]; %faces: 13-24, objects: 49-60



